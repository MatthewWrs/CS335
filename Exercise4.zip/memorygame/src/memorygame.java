import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;

public class memorygame extends JFrame implements ActionListener {
    private int numGuesses = 0;
    private int numMatches = 0;
    private int seconds = 0;
    private int firstGuess = 0;
    // these next variables are used to keep track of the clicked cards and their descriptions
    private int firstCard = 0, secondCard = 0, firstName = 0, secondName = 0;
    private String firstC = "", secondC = "";
    private Timer gameTimer, wrongTimer;
    private JButton start, restart;
    private JTextField time, guesses, matches;
    private JButton[] starwars;
    private ArrayList <ImageIcon> pictures;

    public memorygame() {
        GridBagConstraints gbc = new GridBagConstraints();
        setLayout(new GridBagLayout());
        // spaces buttons apart
        gbc.insets = new Insets(5, 5, 5, 5);

        pictures = new ArrayList<ImageIcon>();

        // stores all the icons into an array list to use to shuffle
        for (int i = 0; i < 16; i++) {
            ImageIcon cardFace = new ImageIcon("icon" + (int)(i) + ".jpg");
            Image img = cardFace.getImage();
            Image newimg = img.getScaledInstance(20, 20, Image.SCALE_SMOOTH);
            cardFace = new ImageIcon(newimg);
            pictures.add(cardFace);
            (pictures.get(i)).setDescription("" + (int)(i));
        }

        // creating all the buttons and their locations
        starwars = new JButton[16];
        for (int i = 0; i < 16; i++) {
            ImageIcon backFace = new ImageIcon("uk.jpg");
            Image img = backFace.getImage();
            Image newimg = img.getScaledInstance(20, 20,  java.awt.Image.SCALE_SMOOTH);
            backFace = new ImageIcon(newimg);
            starwars[i] = new JButton(backFace);
            if (i < 4) {
                gbc.gridx = i;
                gbc.gridy = 1;
            }
            else if (i < 8) {
                gbc.gridx = i -4;
                gbc.gridy = 2;
            }
            else if (i < 12) {
                gbc.gridx = i - 8;
                gbc.gridy = 3;
            }
            else if (i < 16) {
                gbc.gridx = i - 12;
                gbc.gridy = 4;
            }
            starwars[i].addActionListener(this);
            add(starwars[i], gbc);
        }

        // overall game timer used to track how many seconds have gone by in the game
        gameTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
                {
                    seconds++;
                    time.setText("Time: " + seconds);
                }
            }
        );

        // if there is an incorrect pair of cards, they remain shown for 3 seconds before flipping over
        wrongTimer = new Timer(3000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ImageIcon backFace = new ImageIcon("uk.jpg");
                Image img = backFace.getImage();
                Image newimg = img.getScaledInstance(20, 20,  java.awt.Image.SCALE_SMOOTH);
                backFace = new ImageIcon(newimg);
                starwars[firstCard].setIcon(backFace);
                starwars[secondCard].setIcon(backFace);
                firstCard = 0;
                secondCard = 0;
                firstName = 0;
                secondName = 0;
                firstC = "";
                secondC = "";
                wrongTimer.stop();
            }
        });

        start = new JButton("Start");
        gbc.gridx = 0;
        gbc.gridy = 0;
        start.addActionListener(this);
        add(start, gbc);

        restart = new JButton("Restart");
        gbc.gridx = 1;
        gbc.gridy = 0;
        restart.addActionListener(this);
        add(restart, gbc);

        time = new JTextField("Time: ");
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(time, gbc);

        guesses = new JTextField("Guesses: ");
        gbc.gridx = 5;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(guesses, gbc);

        matches = new JTextField("Matches: ");
        gbc.gridx = 8;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(matches, gbc);

        this.setSize(800, 500);

        setVisible(true);

    }

    public void actionPerformed(ActionEvent e) {
        int buttonPressed = -1;
        ImageIcon backFace = new ImageIcon("uk.jpg");
        Image img = backFace.getImage();
        Image newimg = img.getScaledInstance(20, 20,  java.awt.Image.SCALE_SMOOTH);
        backFace = new ImageIcon(newimg);
        Object key = e.getSource();

        // goes through the button array to see if any have been pressed
        for (int i = 0; i < starwars.length; i++) {
            if (key == starwars[i]) {
                buttonPressed = i;
                break;
            }
        }

        if (key == start || key == restart) {
            // restart option completely resets variables
            if (key == restart) {
                gameTimer.stop();
                for (int i = 0; i < starwars.length; i++) {
                    starwars[i].setIcon(backFace);
                }
                numGuesses = 0;
                numMatches = 0;
                seconds = 0;
                firstCard = 0;
                secondCard = 0;
                firstName = 0;
                secondName = 0;
                firstC = "";
                secondC = "";
                firstGuess = 0;
                time.setText("Time: ");
                buttonPressed = -1;
            }
            gameTimer.start();
            // shuffling images instead of buttons
            Collections.shuffle(pictures);
        }

        // assigning an image to a button as the user plays
        if (buttonPressed >= 0) {
            starwars[buttonPressed].setIcon(pictures.get(buttonPressed));
            if (firstGuess == 0) {
                firstC = (pictures.get(buttonPressed)).getDescription();
                firstName = Integer.parseInt(firstC);
                firstCard = buttonPressed;
                // firstGuess keeps track of whether the user is making their first or second pick
                firstGuess++;
            }
            else {
                // using a description to match cards
                secondC = (pictures.get(buttonPressed)).getDescription();
                secondName = Integer.parseInt(secondC);
                secondCard = buttonPressed;
                if (firstName < 8) {
                    if (firstName + 8 == secondName) {
                        numMatches++;
                        firstCard = 0;
                        secondCard = 0;
                        firstName = 0;
                        secondName = 0;
                        firstC = "";
                        secondC = "";
                    }
                    else {
                        wrongTimer.start();
                    }
                }
                else {
                    if (firstName - 8 == secondName) {
                        numMatches++;
                        firstCard = 0;
                        secondCard = 0;
                        firstName = 0;
                        secondName = 0;
                        firstC = "";
                        secondC = "";
                    }
                    else {
                        wrongTimer.start();
                    }
                }
                numGuesses++;
                firstGuess--;
            }

        }
        guesses.setText("Guesses: " + numGuesses);
        matches.setText("Matches: " + numMatches);
        // when all matches have been made then the game ends
        if (numMatches == 8) {
            gameTimer.stop();
        }
    }

    public static void main(String[] args) {
        new memorygame();
    }
}
