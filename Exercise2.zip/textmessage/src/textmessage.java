import javax.swing.*;
import java.awt.*;

public class textmessage extends JFrame {

textmessage() {
    GridBagConstraints gbc = new GridBagConstraints();
    setLayout(new GridBagLayout());
    // spaces buttons apart
    gbc.insets = new Insets(5, 5, 5, 5);

    // stores letters to allow for easier creation of buttons
    String[] letters1 = {"Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"};
    String[] letters2 = {"A", "S", "D", "F", "G", "H", "J", "K", "L"};
    String[] letters3 = {"⇧", "Z", "X", "C", "V", "B", "N", "M", "⌫"};

    // these three for loops create the buttons that have the letters for the keyboard
    for (int i = 0; i < letters1.length; i++) {
        JButton b1 = new JButton(letters1[i]);
        gbc.gridx = i;
        gbc.gridy = 1;
        b1.setForeground(Color.BLUE);
        add(b1, gbc);
    }

    for (int i = 0; i < letters2.length; i++) {
        JButton b1 = new JButton(letters2[i]);
        gbc.gridx = i;
        gbc.gridy = 2;
        b1.setForeground(Color.BLUE);
        add(b1, gbc);
    }

    for (int i = 0; i < letters3.length; i++) {
        JButton b1 = new JButton(letters3[i]);
        gbc.gridx = i;
        gbc.gridy = 3;
        b1.setForeground(Color.BLUE);
        add(b1, gbc);
    }

    JButton b2 = new JButton("+");
    b2.setForeground(Color.BLUE);
    gbc.gridx = 0;
    gbc.gridy = 0;
    add(b2, gbc);
    // creates a text field with a longer width
    JTextField field = new JTextField("Type a message...");
    gbc.gridx = 1;
    gbc.gridy = 0;
    gbc.gridwidth = 8;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    add(field, gbc);
    JButton b3 = new JButton("Send");
    b3.setForeground(Color.WHITE);
    b3.setBackground(Color.BLUE);
    gbc.gridx = 9;
    gbc.gridy = 0;
    gbc.gridwidth = 1;
    add(b3, gbc);

    JButton b4 = new JButton("123");
    gbc.gridx = 0;
    gbc.gridy = 4;
    gbc.gridwidth = 1;
    b4.setForeground(Color.BLUE);
    add(b4, gbc);

    JButton b5 = new JButton("☺");
    gbc.gridx = 1;
    gbc.gridy = 4;
    gbc.gridwidth = 1;
    b5.setForeground(Color.BLUE);
    add(b5, gbc);

    // imports an image and resizes so it fits into the button
    ImageIcon mic = new ImageIcon("mic.png");
    Image img = mic.getImage();
    Image newimg = img.getScaledInstance(20, 20,  java.awt.Image.SCALE_SMOOTH);
    mic = new ImageIcon(newimg);
    JButton b6 = new JButton(mic);
    gbc.gridx = 2;
    gbc.gridy = 4;
    gbc.gridwidth = 1;
    b6.setForeground(Color.BLUE);
    add(b6, gbc);

    JButton b7 = new JButton("Space");
    gbc.gridx = 3;
    gbc.gridy = 4;
    gbc.gridwidth = 6;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    b7.setForeground(Color.BLUE);
    add(b7, gbc);

    JButton b8 = new JButton("Return");
    gbc.gridx = 9;
    gbc.gridy = 4;
    gbc.gridwidth = 1;
    b8.setForeground(Color.BLUE);
    add(b8, gbc);

    this.setSize(700, 500);

    setVisible(true);
}
    public static void main(String[] args) {

    new textmessage();
    }
}
