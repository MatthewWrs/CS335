public class dice {
    public static void main(String[] args) {
        int numTimes[] = {100, 1000, 10000, 100000};
        int counter = 0;

        for (int i = 0; i < numTimes.length; i++) {
            int rolls = numTimes[i];
            for (int j = 0; j < rolls; j++) {
                int bigDice = (int) (Math.random() * 20 + 1);
                int smallDice = (int) (Math.random() * 12 + 1);
                int sum = bigDice + smallDice;
                //System.out.println(sum);

                if (sum == 32) {
                    counter += 1;
                }
            }
            System.out.println(rolls + ": " + counter + " maxed out");
            counter = 0;
        }
    }
}
