public class pi {
    public static void main(String[] args) {
        double piEight = 3.14159265;
        double testNum = 0;
        int terms = 0;

        while ((4.0 * testNum) != piEight) {
            terms += 1;
            if (terms % 2 == 0) {
                testNum += (-1.0 / (2.0 * terms - 1.0));
            }
            else {
                testNum += (1.0 / (2.0 * terms - 1.0));
            }
        }
        System.out.println("Number of terms: " + terms);
    }
}
