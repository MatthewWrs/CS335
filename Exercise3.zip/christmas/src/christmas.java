import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class christmas extends JFrame implements ActionListener {
    private JFrame f;
    private JButton b;
    private JLabel l;
    public christmas(){
        // creates a frame, button, label, and layout to easily read the gui
        f = new JFrame();
        f.setLayout(new FlowLayout());
        b = new JButton("Is it Christmas?");
        b.setSize(200,200);
        b.addActionListener(this);
        f.add(b);

        l = new JLabel();
        l.setSize(100, 100);
        f.add(l);

        f.setSize(300, 300);
        f.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        // finds the date and puts it in day/month format
        SimpleDateFormat formatter  = new SimpleDateFormat("dd/MM");
        Date date = new Date();
        String currDate = formatter.format(date);
        // compares to December 25th (Christmas day) to see if it is Christmas
        if (currDate == "25/12") {
            l.setText("It is Christmas!");
        }
        else {
            l.setText("It is NOT Christmas");
        }
        System.out.println(currDate);
    }

    public static void  main(String[] args){
        new christmas();
    }
}
