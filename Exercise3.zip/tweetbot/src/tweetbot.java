import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class tweetbot extends JFrame implements ActionListener {

    // initializes variable to be used to see if the user has just started using the keyboard
    int firstClick = 0;
    private JButton capsButton, deleteButton, plusButton, sendButton, numbersButton, emoteButton, micButton, spaceButton, returnButton;
    private JTextField field;
    private JButton[] letterButtons;

    public tweetbot() {
        GridBagConstraints gbc = new GridBagConstraints();
        setLayout(new GridBagLayout());
        // spaces buttons apart
        gbc.insets = new Insets(5, 5, 5, 5);

        // stores letters to allow for easier creation of buttons
        String[] letters1 = {"Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"};
        String[] letters2 = {"A", "S", "D", "F", "G", "H", "J", "K", "L"};
        String[] letters3 = {"⇧", "Z", "X", "C", "V", "B", "N", "M"};

        letterButtons = new JButton[27];

        // these three for loops create the buttons that have the letters for the keyboard and their action listeners
        for (int i = 0; i < letters1.length; i++) {
            letterButtons[i] = new JButton(letters1[i]);
            gbc.gridx = i;
            gbc.gridy = 1;
            letterButtons[i].setForeground(Color.BLUE);
            letterButtons[i].addActionListener(this);
            add(letterButtons[i], gbc);
        }

        for (int i = 0; i < letters2.length; i++) {
            letterButtons[i + 10] = new JButton(letters2[i]);
            gbc.gridx = i;
            gbc.gridy = 2;
            letterButtons[i + 10].setForeground(Color.BLUE);
            letterButtons[i + 10].addActionListener(this);
            add(letterButtons[i + 10], gbc);
        }

        for (int i = 0; i < letters3.length; i++) {
            letterButtons[i + 19] = new JButton(letters3[i]);
            gbc.gridx = i;
            gbc.gridy = 3;
            letterButtons[i + 19].setForeground(Color.BLUE);
            if (i != 0) {
                letterButtons[i + 19].addActionListener(this);
            }
            add(letterButtons[i + 19], gbc);
        }

        // creating a backspace button along with the action listener
        deleteButton = new JButton("⌫");
        deleteButton.setForeground(Color.BLUE);
        gbc.gridx = 8;
        gbc.gridy = 3;
        deleteButton.addActionListener(this);
        add(deleteButton, gbc);

        plusButton = new JButton("+");
        plusButton.setForeground(Color.BLUE);
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(plusButton, gbc);
        // creates a text field with a longer width
        field = new JTextField("Type a message...");
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 8;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(field, gbc);
        sendButton = new JButton("Send");
        sendButton.setForeground(Color.WHITE);
        sendButton.setBackground(Color.BLUE);
        gbc.gridx = 9;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        sendButton.addActionListener(this);
        add(sendButton, gbc);

        numbersButton = new JButton("123");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        numbersButton.setForeground(Color.BLUE);
        add(numbersButton, gbc);

        emoteButton = new JButton("☺");
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        emoteButton.setForeground(Color.BLUE);
        emoteButton.addActionListener(this);
        add(emoteButton, gbc);

        // imports an image and resizes so it fits into the button
        ImageIcon mic = new ImageIcon("mic.png");
        Image img = mic.getImage();
        Image newimg = img.getScaledInstance(20, 20,  java.awt.Image.SCALE_SMOOTH);
        mic = new ImageIcon(newimg);
        micButton = new JButton(mic);
        gbc.gridx = 2;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        micButton.setForeground(Color.BLUE);
        add(micButton, gbc);

        spaceButton = new JButton("Space");
        gbc.gridx = 3;
        gbc.gridy = 4;
        gbc.gridwidth = 6;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        spaceButton.setForeground(Color.BLUE);
        spaceButton.addActionListener(this);
        add(spaceButton, gbc);

        returnButton = new JButton("Return");
        gbc.gridx = 9;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        returnButton.setForeground(Color.BLUE);
        add(returnButton, gbc);

        this.setSize(700, 500);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        int keyPressed = -1;
        String text = "";
        Object key = e.getSource();

        // clears the text field when the user first starts typing
        if (firstClick == 0) {
            field.setText("");
            firstClick = 1;
        }

        // checks to see if the button that is pressed is a letter
        for (int i = 0; i < letterButtons.length; i++) {
            if (key == letterButtons[i]) {
                keyPressed = i;
                break;
            }
        }

        if (keyPressed == -1) {
            if (key == deleteButton) {
                String str = field.getText();
                String newStr = str.substring(0, str.length() - 1);
                field.setText(newStr);
            }
            else if (key == spaceButton) {
                field.setText(field.getText() + " ");
            }
            else if (key == emoteButton) {
                field.setText(field.getText() + ":-)");
            }
            else if (key == sendButton) {
                System.out.println(field.getText());
            }
        }
        else {
            text = letterButtons[keyPressed].getText();
            field.setText(field.getText() + text);
        }
    }

    public static void main(String[] args) {
        new tweetbot();
    }
}
