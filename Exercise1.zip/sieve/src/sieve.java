import java.util.Arrays;

public class sieve {
    public static void main(String[] args) {
        boolean[] testArr = new boolean[10000];
        Arrays.fill(testArr, true); //all elements in array begin as true
        testArr[0] = false;

        for (int z = 2; z < testArr.length + 1; z++) { //loops through possible divisors
            for (int y = 3; y < testArr.length + 1; y++) { //loops through possible prime numbers
                if (y != z) {
                    if (testArr[y - 1]) { //if the element is currently set to true
                        if ((y % z) == 0) {
                            testArr[y - 1] = false; // y-1 used to correct loop since it is off by one
                        }
                    }
                }
            }
        }

        int numTerms = 0;
        for (int w = 0; w < testArr.length; w++) {
            if (w % 100 == 0) { // prints out primes by 100s, 200s, 300s, etc.
                System.out.println();
            }
            if (testArr[w]) { //if element is set to true
                numTerms++;
                System.out.print((w + 1) + " "); // w+1 used since index off by one
            }
        }

        System.out.println("\n");
        System.out.println("There are " + numTerms + " primes less than 10,000");
    }
}
