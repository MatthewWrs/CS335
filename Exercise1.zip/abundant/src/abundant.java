public class abundant {
    public static void main(String[] args) {
        int amtTerms = 10000;
        int highestAbundance = 0;
        int bestNum = 10000; //holds the smallest number with highest abundance
        int numAbundant = 0;
        int hold = 0; //used to compare numbers with the same abundance to determine which is smaller

        for (int a = 1; a < amtTerms; a++) { //loop for each term from less than 10,000
            int summation = 0;
            for (int b = 1; b < a; b++) { //loop to find divisor of each term
                if (a % b == 0) {
                    summation += b; //adds all divisors of the term together
                }
            }
            if (summation > a) {
                numAbundant++;
                hold = 0;
                hold = summation - a;
                if (hold >= highestAbundance) {
                    if (hold == highestAbundance) {
                        if (a < bestNum) {
                            bestNum = a; //updates if there is a smaller number with equal or greater abundance
                        }
                    }
                    else {
                        highestAbundance = hold; //updates the highest abundance found associated with a term
                        bestNum = a;
                    }
                }
            }
        }
        System.out.println("There are " + numAbundant + " abundant numbers less than 10,000");
        System.out.println("The smallest abundant number (less than 10,000) with highest abundance is " + bestNum);
    }
}
