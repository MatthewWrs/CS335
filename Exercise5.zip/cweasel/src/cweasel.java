import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;

public class cweasel extends JFrame implements ActionListener {

    private JFrame game, helpWindow, settingsWindow, lose;
    private JPanel board, menu, settings1, settings2;
    private JButton start, settings, help, quit, quit2, beginner, intermediate, expert, done, restart;
    private Timer gameTimer;
    private JTextField time, counter;
    private JTextArea helpText, gridDescription, trapDescription, loseText;
    private JComboBox gridSize, trapAmt;
    private JButton[][] cells;
    private int[][] clicked, cleared;
    private int seconds = 0;
    private int firstClick = 0;
    private int testDimension;
    private ImageIcon trap, clear;
    private ArrayList <ImageIcon> pictures;

    public cweasel(int overallDimension, int overallTrap) {
        game = new JFrame("The Yellowstone Caldera Weasel");
        game.setLayout(new GridLayout(2, 1));
        menu = new JPanel(new GridLayout());

        start = new JButton("Start");
        start.addActionListener(this);
        menu.add(start);
        time = new JTextField("Time: ");
        menu.add(time);
        counter = new JTextField("Thermal Traps: " + overallTrap);
        menu.add(counter);
        settings = new JButton("Settings");
        settings.addActionListener(this);
        menu.add(settings);
        help = new JButton("Help");
        help.addActionListener(this);
        menu.add(help);
        quit = new JButton("Quit");
        quit.addActionListener(this);
        menu.add(quit);
        game.add(menu);

        testDimension = overallDimension;
        buildBoard(overallDimension);
        setTraps(overallTrap, overallDimension);

        gameTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                seconds++;
                time.setText("Time: " + seconds);
            }
        }
        );

        game.setSize(1000,1000);
        game.setVisible(true);
    }

    public void settingsAppear() {
        settingsWindow = new JFrame("Settings");
        settingsWindow.setLayout(new GridLayout(2, 1));
        settings1 = new JPanel(new GridLayout(2, 2));

        gridDescription = new JTextArea();
        gridDescription.setText(
                "Select a grid size\n" +
                        "The number you select will represent the dimensions\n" +
                        "Ex. 4 = 4x4, 10 = 10x10"
        );
        gridDescription.setEditable(false);
        settings1.add(gridDescription);

        String[] grids = {"4", "5", "8", "10", "15"};
        gridSize = new JComboBox(grids);
        gridSize.setEditable(false);
        settings1.add(gridSize);

        trapDescription = new JTextArea();
        trapDescription.setText(
                "Select the number of traps\n" +
                        "After selecting both make sure to click DONE\n" +
                        "Or select a difficulty then click DONE\n" +
                        "Make sure to click DONE!"
        );
        trapDescription.setEditable(false);
        settings1.add(trapDescription);

        String[] traps = {"5", "10", "14", "15", "30", "60"};
        trapAmt = new JComboBox(traps);
        trapAmt.setEditable(false);
        settings1.add(trapAmt);

        settingsWindow.add(settings1);

        settings2 = new JPanel(new FlowLayout());
        beginner = new JButton("Beginner");
        beginner.addActionListener(this);
        settings2.add(beginner);
        intermediate = new JButton("Intermediate");
        intermediate.addActionListener(this);
        settings2.add(intermediate);
        expert = new JButton("Expert");
        expert.addActionListener(this);
        settings2.add(expert);
        done = new JButton("DONE");
        done.addActionListener(this);
        settings2.add(done);

        settingsWindow.add(settings2);

        settingsWindow.setSize(500, 500);
        settingsWindow.setVisible(true);
    }

    public void helpAppear() {
        helpWindow = new JFrame("Help");
        helpWindow.setLayout(new FlowLayout());
        helpText = new JTextArea();
        helpText.setText(
                "Instructions: \n" +
                        "Click a button to start!\n" +
                        "Make sure not to click any thermal traps!\n" +
                        "The number on the button represents how many traps surround!\n" +
                        "Be careful and GOOD LUCK"
        );

        helpText.setEditable(false);
        helpWindow.add(helpText);

        helpWindow.setSize(500, 500);
        helpWindow.setVisible(true);
    }

    public void buildBoard(int dimension) {
        board = new JPanel(new GridLayout(dimension, dimension));
        cells = new JButton[dimension][dimension];
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                cells[i][j] = new JButton();
                cells[i][j].addActionListener(this);
                board.add(cells[i][j]);
            }
        }
        game.add(board);
    }

    public void setTraps(int numTraps, int dimension) {
        pictures = new ArrayList<ImageIcon>();

        trap = new ImageIcon("trap.png");
        Image img = trap.getImage();
        Image newImg = img.getScaledInstance(20, 20,  java.awt.Image.SCALE_SMOOTH);
        trap = new ImageIcon(newImg);

        clear = new ImageIcon("blue.png");

        for (int i = 0; i < numTraps; i++) {
            pictures.add(trap);
            (pictures.get(i)).setDescription("trap");
        }
        int numCells = dimension * dimension;
        for (int i = numTraps; i < numCells; i++) {
            pictures.add(clear);
            (pictures.get(i)).setDescription("clear");
        }
        Collections.shuffle(pictures);
        clicked = new int[dimension][dimension];
        cleared = new int[dimension][dimension];
    }

    public void reveal(int buttonPressedX, int buttonPressedY, int buttonSelected, int dimension) {
        int surroundingTraps = 0;
        int newSelection = 0, newX = 0, newY = 0;
        int north = (buttonPressedX - 1) * dimension + buttonPressedY;
        int south = (buttonPressedX + 1) * dimension + buttonPressedY;
        int west = (buttonPressedX * dimension) + (buttonPressedY - 1);
        int east = (buttonPressedX * dimension) + (buttonPressedY + 1);
        int ne = ((buttonPressedX - 1) * dimension) + (buttonPressedY - 1);
        int nw = ((buttonPressedX - 1) * dimension) + (buttonPressedY + 1);
        int se = ((buttonPressedX + 1) * dimension) + (buttonPressedY + 1);
        int sw = ((buttonPressedX + 1) * dimension) + (buttonPressedY - 1);

        cells[buttonPressedX][buttonPressedY].setIcon(pictures.get(buttonSelected));

        if (Objects.equals(pictures.get(buttonSelected).getDescription(), "trap")) {
            return;
        }

        if (Objects.equals(pictures.get(buttonSelected).getDescription(), "clear") && cleared[buttonPressedX][buttonPressedY] == 0) {
            cleared[buttonPressedX][buttonPressedY] = 1;
            if ((buttonPressedX - 1) >= 0 && (buttonPressedX - 1) < dimension && buttonPressedY >= 0 && buttonPressedY < dimension) {
                if (Objects.equals(pictures.get(north).getDescription(), "trap")) {
                    surroundingTraps++;
                }
            }
            if ((buttonPressedX + 1) >= 0 && (buttonPressedX + 1) < dimension && buttonPressedY >= 0 && buttonPressedY < dimension) {
                if (Objects.equals(pictures.get(south).getDescription(), "trap")) {
                    surroundingTraps++;
                }
            }
            if (buttonPressedX >= 0 && buttonPressedX < dimension && (buttonPressedY - 1) >= 0 && (buttonPressedY - 1) < dimension) {
                if (Objects.equals(pictures.get(west).getDescription(), "trap")) {
                    surroundingTraps++;
                }
            }
            if (buttonPressedX >= 0 && buttonPressedX < dimension && (buttonPressedY + 1) >= 0 && (buttonPressedY + 1) < dimension) {
                if (Objects.equals(pictures.get(east).getDescription(), "trap")) {
                    surroundingTraps++;
                }
            }
            if ((buttonPressedX - 1) >= 0 && (buttonPressedX - 1) < dimension && (buttonPressedY - 1) >= 0 && (buttonPressedY - 1) < dimension) {
                if (Objects.equals(pictures.get(ne).getDescription(), "trap")) {
                    surroundingTraps++;
                }
            }
            if ((buttonPressedX - 1) >= 0 && (buttonPressedX - 1) < dimension && (buttonPressedY + 1) >= 0 && (buttonPressedY + 1) < dimension) {
                if (Objects.equals(pictures.get(nw).getDescription(), "trap")) {
                    surroundingTraps++;
                }
            }
            if ((buttonPressedX + 1) >= 0 && (buttonPressedX + 1) < dimension && (buttonPressedY + 1) >= 0 && (buttonPressedY + 1) < dimension) {
                if (Objects.equals(pictures.get(se).getDescription(), "trap")) {
                    surroundingTraps++;
                }
            }
            if ((buttonPressedX + 1) >= 0 && (buttonPressedX + 1) < dimension && (buttonPressedY - 1) >= 0 && (buttonPressedY - 1) < dimension) {
                if (Objects.equals(pictures.get(sw).getDescription(), "trap")) {
                    surroundingTraps++;
                }
            }

            if ((buttonPressedX - 1) >= 0 && (buttonPressedX - 1) < dimension && buttonPressedY >= 0 && buttonPressedY < dimension) {
                if (Objects.equals(pictures.get(north).getDescription(), "clear") && surroundingTraps == 0) {
                    newX = buttonPressedX - 1;
                    newY = buttonPressedY;
                    newSelection = newX * dimension + newY;
                    reveal(newX, newY, newSelection, dimension);
                }
            }
            if ((buttonPressedX + 1) >= 0 && (buttonPressedX + 1) < dimension && buttonPressedY >= 0 && buttonPressedY < dimension) {
                if (Objects.equals(pictures.get(south).getDescription(), "clear") && surroundingTraps == 0) {
                    newX = buttonPressedX + 1;
                    newY = buttonPressedY;
                    newSelection = newX * dimension + newY;
                    reveal(newX, newY, newSelection, dimension);
                }
            }
            if (buttonPressedX >= 0 && buttonPressedX < dimension && (buttonPressedY - 1) >= 0 && (buttonPressedY - 1) < dimension) {
                if (Objects.equals(pictures.get(west).getDescription(), "clear") && surroundingTraps == 0) {
                    newX = buttonPressedX;
                    newY = buttonPressedY - 1;
                    newSelection = newX * dimension + newY;
                    reveal(newX, newY, newSelection, dimension);
                }
            }
            if (buttonPressedX >= 0 && buttonPressedX < dimension && (buttonPressedY + 1) >= 0 && (buttonPressedY + 1) < dimension) {
                if (Objects.equals(pictures.get(east).getDescription(), "clear") && surroundingTraps == 0) {
                    newX = buttonPressedX;
                    newY = buttonPressedY + 1;
                    newSelection = newX * dimension + newY;
                    reveal(newX, newY, newSelection, dimension);
                }
            }
            if ((buttonPressedX - 1) >= 0 && (buttonPressedX - 1) < dimension && (buttonPressedY - 1) >= 0 && (buttonPressedY - 1) < dimension) {
                if (Objects.equals(pictures.get(ne).getDescription(), "clear") && surroundingTraps == 0) {
                    newX = buttonPressedX - 1;
                    newY = buttonPressedY - 1;
                    newSelection = newX * dimension + newY;
                    reveal(newX, newY, newSelection, dimension);
                }
            }
            if ((buttonPressedX - 1) >= 0 && (buttonPressedX - 1) < dimension && (buttonPressedY + 1) >= 0 && (buttonPressedY + 1) < dimension) {
                if (Objects.equals(pictures.get(nw).getDescription(), "clear") && surroundingTraps == 0) {
                    newX = buttonPressedX - 1;
                    newY = buttonPressedY + 1;
                    newSelection = newX * dimension + newY;
                    reveal(newX, newY, newSelection, dimension);
                }
            }
            if ((buttonPressedX + 1) >= 0 && (buttonPressedX + 1) < dimension && (buttonPressedY + 1) >= 0 && (buttonPressedY + 1) < dimension) {
                if (Objects.equals(pictures.get(se).getDescription(), "clear") && surroundingTraps == 0) {
                    newX = buttonPressedX + 1;
                    newY = buttonPressedY + 1;
                    newSelection = newX * dimension + newY;
                    reveal(newX, newY, newSelection, dimension);
                }
            }
            if ((buttonPressedX + 1) >= 0 && (buttonPressedX + 1) < dimension && (buttonPressedY - 1) >= 0 && (buttonPressedY - 1) < dimension) {
                if (Objects.equals(pictures.get(sw).getDescription(), "clear") && surroundingTraps == 0) {
                    newX = buttonPressedX + 1;
                    newY = buttonPressedY - 1;
                    newSelection = newX * dimension + newY;
                    reveal(newX, newY, newSelection, dimension);
                }
            }
        }

        if (surroundingTraps > 0) {
            cells[buttonPressedX][buttonPressedY].setText("" + surroundingTraps);
            cells[buttonPressedX][buttonPressedY].setHorizontalTextPosition(SwingConstants.CENTER);
            cells[buttonPressedX][buttonPressedY].setForeground(Color.WHITE);
        }



    }

    public void loss() {
        lose = new JFrame("You LOST!!!");
        lose.setLayout(new GridLayout(3, 1));
        loseText = new JTextArea();
        loseText.setText(
                "YOU LOST\n" + "YOU LOST\n" + "YOU LOST\n" +
                        "Your time was: " + seconds + " seconds\n" +
                        "Better luck next time!"
        );

        loseText.setEditable(false);
        lose.add(loseText);

        restart = new JButton("Restart?");
        restart.addActionListener(this);
        lose.add(restart);

        quit2 = new JButton("Quit");
        quit2.addActionListener(this);
        lose.add(quit2);

        lose.setSize(500, 500);
        lose.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        int buttonPressedX = -1;
        int buttonPressedY = -1;
        Object key = e.getSource();

        for (int i = 0; i < testDimension; i++) {
            for (int j = 0; j < testDimension; j++) {
                if (key == cells[i][j] && clicked[i][j] == 0) {
                    buttonPressedX = i;
                    buttonPressedY = j;
                    clicked[i][j] = 1;
                    break;
                }
            }
        }

        if (key == start) {
            seconds = 0;
            time.setText("Time: " + seconds);
            gameTimer.start();
        }

        if (key == settings) {
            settingsAppear();
        }

        if (key == beginner) {
            gridSize.setSelectedItem("4");
            trapAmt.setSelectedItem("5");
        }

        if (key == intermediate) {
            gridSize.setSelectedItem("8");
            trapAmt.setSelectedItem("14");
        }

        if (key == expert) {
            gridSize.setSelectedItem("15");
            trapAmt.setSelectedItem("60");
        }

        if (key == done) {
            String size = gridSize.getSelectedItem() + "";
            String trap = trapAmt.getSelectedItem() + "";

            int sizeInt = Integer.parseInt(size);
            int trapInt = Integer.parseInt(trap);

            game.dispose();
            new cweasel(sizeInt, trapInt);

            settingsWindow.dispose();
        }

        if (key == help) {
            helpAppear();
        }

        if (key == restart) {
            lose.dispose();
            game.dispose();
            new cweasel(4, 5);
        }

        if (key == quit || key == quit2) {
            if (key == quit2) {
                lose.dispose();
            }
            game.dispose();
            System.exit(0);
        }

        if (buttonPressedX >= 0) {
            int buttonSelected = 0;
            buttonSelected = (buttonPressedX * testDimension) + buttonPressedY;
            while (firstClick == 0) {

                if (Objects.equals(pictures.get(buttonSelected).getDescription(), "trap")) {
                    Collections.shuffle(pictures);
                }
                else {
                    firstClick = 1;
                    gameTimer.start();
                }
            }
            reveal(buttonPressedX, buttonPressedY, buttonSelected, testDimension);
            if (Objects.equals(pictures.get(buttonSelected).getDescription(), "trap")) {
                gameTimer.stop();
                loss();
            }
        }

    }

    public static void main(String[] args) {
        new cweasel(4, 5);
    }
}
